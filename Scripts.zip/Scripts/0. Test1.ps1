--: PROMPT tableCount = 'Enter the number of test tables to create'

--: SET i = 0

--: WHILE i < tableCount

--: SET i = i + 1  

CREATE TABLE testTable{{Unquote(:i)}} ( id INT PRIMARY KEY );

--: ENDWHILE

--: NOTIFY 'Done creating tables.'

--: ASK addData = 'Fill tables with test data?'

--: IF addData

--: PROMPT rowCount = 'Enter number of rows to create'  

--: SET i = 0  

--: WHILE i < tableCount  

--: SET i = i + 1    

--: SET j = 1    

--: WHILE j <= rowCount    

INSERT INTOtestTable{{Unquote(:i)}} VALUES (:j);

--: SET j = j + 1      

--: ENDWHILE    

--: PRINT 'Completed filling table ' || i    

--: ENDWHILE  

--:ENDIF