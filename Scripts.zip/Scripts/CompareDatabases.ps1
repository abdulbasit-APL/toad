﻿#-------------------------------------------------------------------------------------------------------------------------------
# Copyright (c) 2017 Quest Software
#
# Name: CompareDatabases.ps1
#
# Description :  Compares a Source and Target Database and returns Difference reports, Snapshot and Sync scripts
#-------------------------------------------------------------------------------------------------------------------------------


$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                 # Start TDT


try {
     # Make Connections to Source and Target Databases
     $Source = $TDT.Connections.NewConnection('source_user/source_pwd@sourcedb')   # Source DB credentials
     $Target = $TDT.Connections.NewConnection('target_user/target_pwd@targetdb')   # Target DB credentials


     # Set Database Compare Parameters
     $TDT.CompareDatabases.ObjectTypes.IncludeAll()                                # Include all Object Types parameter
     $TDT.CompareDatabases.SourceDatabase = "source_schema@sourcedb"               # Set Source DB Schema
   

     # Add Target Information and Output Files
     $Target = $TDT.CompareDatabases.Targets.Add()                                     
     $Target.Connection            = "target_schema@targetdb"                      # Set Target DB Schema 
     $Target.DifferenceDetails     = "C:\Temp\DBCompare_DiffDetails.txt"           # Difference Details Report Location/Name
     $Target.DifferenceSummary     = "C:\Temp\DBCompare_DiffSummary.htm"           # Difference Summary Report Location/Name
     $Target.SchemaSnapshot        = "C:\Temp\DBCompare_Snapshot.json"             # Schema Snapshot Location/Name
     $Target.SyncScript            = "C:\Temp\DBCompare_SyncScript.sql"            # Sync Script Location/Name

    
     # Run Database Compare
     $TDT.CompareDatabases.Execute()
    }

finally {
         $TDT.Quit()                                                                # Stop TDT
        }

