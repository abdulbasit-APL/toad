﻿#-------------------------------------------------------------------------------------------------------------------------------
# Copyright (c) 2017 Quest Software
#
# Name        :  CodeAnalysis.ps1
# Description :  Runs Code Analysis for a given database object and creates a HTML report.
#-------------------------------------------------------------------------------------------------------------------------------


$TDT = New-Object -ComObject 'Toad.ToadAutoObject'                                   # Start TDT


try {
     # Set CA parameters
     $TDT.CodeAnalysis.Connection   = $TDT.Connections.NewConnection('user/pwd@db')  # Source DB credentials
     $TDT.CodeAnalysis.ReportName   = "Code Analysis Report"                         # Report Name Title
     $TDT.CodeAnalysis.OutputFolder = "C:\Temp"                                      # Local Output folder Name
     $TDT.CodeAnalysis.ReportFormats.IncludeHTML = $TRUE                             # Include All CA Report formats


     # Set DB Object Information to Analyze
     $DBObject = $TDT.CodeAnalysis.DBObjects.Add()              
     $DBObject.ObjectName  = 'ObjectName'                                            # Object Name      (e.g. 'DEMO_FUNCTION')           
     $DBObject.ObjectOwner = 'SchemaName'                                            # Schema Name      (e.g. 'SCOTT', 'HR')
     $DBObject.ObjectType  = 'ObjectType'                                            # Object Type Name (e.g. 'FUNCTION', 'PROCEDURE')

               
     # Execute Code Analysis  
     $TDT.CodeAnalysis.Execute()

    }

finally {
         $TDT.Quit()                                                                 # Stop TDT
        }
