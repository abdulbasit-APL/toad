/*--------------------------------------------------------------------*/
/*  Copyright (c) 2017 Quest Software                                 */
/*  This is an example of how to use PL/SQL to run TDT.  It uses the  */ 
/*  ordcom package to get/set properties and run (invoke) methods.    */
/*                                                                    */
/*  The steps performed in this script are as follows:                */
/*    Step 1:  Start TDT                                              */
/*    Step 2:  Get Connections Property                               */
/*    Step 3:  Set Connection Arguments (Database connection info)    */
/*    Step 4:  Make a DB Connection                                   */
/*    Step 5:  Stop TDT                                               */
/*--------------------------------------------------------------------*/

declare

----------------------------------------------
l_tdt_object        varchar2(100) := 'Toad.ToadAutoObject';
l_db_connection     varchar2(100) := 'scott/tiger@{DBName}';   
----------------------------------------------
l_result            binary_integer;
l_object_token      binary_integer := -1;
l_com_token         binary_integer;
l_error_src         varchar2(255);
l_error_description varchar2(255);
l_error_helpfile    varchar2(255);
l_error_helpid      binary_integer;
dummy               binary_integer;
error_exception     exception;


begin
  
    /*-- Step 1:  Starting TDT --*/
    dbms_output.put_line('Starting TDT');
    l_result := com.ordcom.createobject(l_tdt_object, 0, '', l_object_token);

    if l_result != 0 then
       raise error_exception;
    end if;


   /*-- Step 2:  Get Connections Property --*/
   dbms_output.put_line('...Getting Connections property');
   l_result := com.ordcom.getproperty(l_object_token, 'Connections', 0, l_com_token);

   if l_result != 0 then
      raise error_exception;
   end if;
 

   /*-- Step 3:  Setting Connection arguments - DB Connection Info --*/ 
   dbms_output.put_line('...Setting Connection Arguments');
   com.ordcom.initarg();
   com.ordcom.setarg(l_db_connection, 'BSTR');


   /*-- Step 4:  Make Connection --*/    
   dbms_output.put_line('...Running NewConnection');
   l_result := com.ordcom.invoke(l_com_token, 'NewConnection', 1, dummy);
 
   if l_result != 0 then
      raise error_exception;
   else
      dbms_output.put_line('...Connected to: '||l_db_connection);
   end if;   

  
   /*-- Step 5:  Stop TDT --*/
   l_result := com.ordcom.invoke(l_object_token, 'Quit', 0, dummy);
  
   if l_result != 0 then
      raise error_exception;
   else
      dbms_output.put_line('TDT Stopped');
   end if;
  

   /*-- Step 6:  Stop TDT --*/  
   l_result := com.ordcom.destroyobject(l_object_token);
   l_result := com.ordcom.destroyobject(l_com_token);


exception when error_exception then
             /*-- Get Error Info --*/
             com.ordcom.getlasterror(l_error_src, l_error_description, l_error_helpfile, l_error_helpid);     
             dbms_output.put_line('Result: '||l_result);
             dbms_output.put_line('Error Source        : '||l_error_src);
             dbms_output.put_line('Error Description   : '||l_error_description);
             dbms_output.put_line('Error HelpID        : '||l_error_helpid);
             l_result := com.ordcom.invoke(l_object_token, 'Quit', 0, dummy);
             l_result := com.ordcom.destroyobject(l_object_token);
             l_result := com.ordcom.destroyobject(l_com_token);

         when others then 
            dbms_output.put_line(SQLERRM);

end;

