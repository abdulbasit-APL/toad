﻿#-------------------------------------------------------------------------------------------------------------------------------
# Copyright (c) 2017 Quest Software
#
# Name: Debug.ps1
#
# Description :  Runs Debug and Outputs different possible output debug files
#-------------------------------------------------------------------------------------------------------------------------------


# Start TDT
$TDT = New-Object -ComObject 'Toad.ToadAutoObject'   # Start TDT



try {
     # Get Logfile Text and write to file
     $TDT.Debug.Logfile.GetText() | Out-File -FilePath "C:\Temp\Logfile.txt" -Force

      
     # Get Logfile Filename
     $DebugFile = $TDT.Debug.Logfile.Filename()
     
 
     # Get Exception Log Filename
     $ExceptionLogFile = $TDT.Debug.ExceptionLog.Filename()


     # Get Exception Log - Last Error and write to file
     $TDT.Debug.ExceptionLog.GetLastError()     | Out-File -FilePath "C:\Temp\LastError.txt" -Force


     # Get Exception Log - Last Call Stack and write to file      
     $TDT.Debug.ExceptionLog.GetLastCallStack() | Out-File -FilePath "C:\Temp\LastCallStack.txt" -Force


     # Get Exception Log - Last Call Last Report and write to file            
     $TDT.Debug.ExceptionLog.GetLastReport()    | Out-File -FilePath "C:\Temp\LastReport.txt" -Force


     # Get Exception Log - Full Report and write to file                 
     $TDT.Debug.ExceptionLog.GetFullReport()    | Out-File -FilePath "C:\Temp\FullReport.txt" -Force
    }



finally {
         $TDT.Quit()                                 # Stop TDT
        }     