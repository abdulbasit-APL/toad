<#
.SYNOPSIS

Run Code Tester tests.

.DESCRIPTION

Copyright (c) 2019 Quest Software Inc. ALL RIGHTS RESERVED.

A simple example that uses Toad DevOps Toolkit to run Code Tester tests.

.NOTES

An example request body has been provided which should be customized to your setup.

By default the script fails (sets a non-zero exit code) when a test does not succeed.

.LINK

https://qsft.github.io/tdt-rest

#>

# By default the server uses a self-signed certificate.
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
# TLS 1.2 is required when communicating wih the server.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

try {
  $Body = @{
    Connection = 'DEMO/demo@toadorabpc12cr2.eastus.cloudapp.azure.com:1521/QA_TARGET'
    Objects = @(@{
      Name = '%'
      Owner = 'DEMO'
    })
  }

  # Convert the PowerShell body to json.
  $Json = $Body | ConvertTo-Json

  'Requesting to run Code Tester tests...'
  $Response = Invoke-WebRequest -Uri 'https://localhost:5000/api/unittests/codetester/tests/run' -Method Post -Body $Json -ContentType 'application/json'
  $CodeTesterJob = $Response.Content | ConvertFrom-Json

  # Poll the job until the Code Tester tests job has an expected status of 'Finished' or the maximum number of retries has been hit.
  for ($i = 0; $i -lt 10; $i++) {
    'Polling the Code Tester tests status {0}...'-f ($i + 1)

    # Wait a number of seconds between each polling of the status.
    Start-Sleep -S 5

    # Get the job's latest status.
    $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/jobs/{0}' -f $CodeTesterJob.Id) -Method Get -ContentType 'application/json'
    $CodeTesterJob = $Response.Content | ConvertFrom-Json

    if ($CodeTesterJob.Status -eq 'Finished') { break }
  }

  'Gathering results of Code Tester tests...'
  # Get the job's results once the status has finished.
  $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/unittests/codetester/tests/run/results/{0}' -f $CodeTesterJob.Id) -Method Get -ContentType 'application/json'
  $CodeTesterResults = $Response.Content | ConvertFrom-Json

  'Code Tester ran {0} tests' -f $CodeTesterResults.Tests.Count
  # Return tests that did not succeed.
  $CodeTesterResults.Tests | forEach { if ($_.LastRunStatus -ne 'SUCCESS') { $_ } }
  # Return a non-zero exit code when a test has not been successful.
  if ($CodeTesterResults.Tests.LastRunStatus -notcontains 'SUCCESS') { exit 1 }
} catch {
  $_.Exception.Message
  exit 1
}