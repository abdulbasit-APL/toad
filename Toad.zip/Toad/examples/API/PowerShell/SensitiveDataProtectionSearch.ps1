<#
.SYNOPSIS

Search using Sensitive Data Protection.

.DESCRIPTION

Copyright (c) 2019 Quest Software Inc. ALL RIGHTS RESERVED.

A simple example that uses Toad DevOps Toolkit to search using Sensitive Data Protection.

.NOTES

An example request body has been provided which should be customized to your setup.

By default the script fails (sets a non-zero exit code) when any exceptions occur.

.LINK

https://qsft.github.io/tdt-rest

#>

# By default the server uses a self-signed certificate.
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
# TLS 1.2 is required when communicating wih the server.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Try {
  $Body = @{
    Connection = 'user/password@database'
    Schemas = @('schema')
    Options = @{
      ReportName = 'Sensitive Data Protection Report'
    }
    Output = @{
      Formats = @('html')
      FolderPath = 'C:\Examples'
    }
  }

  # Convert the PowerShell body to json.
  $Json = $Body | ConvertTo-Json

  'Requesting to search using Sensitive Data Protection...'
  $Response = Invoke-WebRequest -Uri 'https://localhost:5000/api/sensitivedataprotection/search' -Method Post -Body $Json -ContentType 'application/json'
  $SearchSensitiveDataProtectionJob = $Response.Content | ConvertFrom-Json

  # Poll the job until the Sensitive Data Protection search job has an expected status of 'Finished' or the maximum number of retries has been hit.
  for ($i = 0; $i -lt 10; $i++) {
    'Polling the Sensitive Data Protection Search status {0}...'-f ($i + 1)

    # Wait a number of seconds between each polling of the status.
    Start-Sleep -S 5
    
    # Get the job's latest status.
    $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/jobs/{0}' -f $SearchSensitiveDataProtectionJob.Id) -Method Get -ContentType 'application/json'
    $SearchSensitiveDataProtectionJob = $Response.Content | ConvertFrom-Json

    if ($SearchSensitiveDataProtectionJob.Status -eq 'Finished') { break }
  }

  'Gathering results of the Sensitive Data Protection Search...'
  # Get the job's results once the status has finished.
  $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/sensitivedataprotection/search/results/{0}' -f $SearchSensitiveDataProtectionJob.Id) -Method Get -ContentType 'application/json'
  $SearchSensitiveDataProtectionResults = $Response.Content | ConvertFrom-Json

  'Sensitive Data Protection Search returned {0} results' -f $SearchSensitiveDataProtectionResults.Results.Count
  # Return a non-zero exit code when an error or rule violation has occurred.
  if ($SearchSensitiveDataProtectionResults.Results.Count -gt 0) {
    $SearchSensitiveDataProtectionResults.Results | forEach { $_ }
    exit 1
  }
} Catch {
  $_.Exception.Message
  exit 1
}