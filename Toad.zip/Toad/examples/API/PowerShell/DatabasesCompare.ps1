<#
.SYNOPSIS

Compare databases between a live source connection and a target snapshot file.

.DESCRIPTION

Copyright (c) 2019 Quest Software Inc. ALL RIGHTS RESERVED.

A simple example that uses Toad DevOps Toolkit to compare databases between a live connection and snapshot file.

.NOTES

An example request body has been provided which should be customized to your setup.

By default the script fails (sets a non-zero exit code) when any exceptions occur.

.LINK

https://qsft.github.io/tdt-rest

#>

# By default the server uses a self-signed certificate.
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
# TLS 1.2 is required when communicating wih the server.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Try {
  $Body = @{
    Source = @{
      Connection = 'user/password@database'
    }
    Target = @{
      Snapshot = @{
        FilePath = 'C:\Examples\TargetSnapshot.ddxml'
      }
    }
    Compare = @{
      ObjectTypes = @{
        All = $True
      }
    }
    Output = @{
      SyncScript = @{
        FilePath = 'C:\Examples\SyncScript.sql'
      }
    }
  }

  # Convert the PowerShell body to json.
  $Json = $Body | ConvertTo-Json

  'Requesting to compare databases...'
  $Response = Invoke-WebRequest -Uri 'https://localhost:5000/api/databases/compare' -Method Post -Body $Json -ContentType 'application/json'
  $CompareDatabasesJob = $Response.Content | ConvertFrom-Json

  # Poll the job until the compare databases job has an expected status of 'Finished' or the maximum number of retries has been hit.
  for ($i = 0; $i -lt 10; $i++) {
    'Polling the compare databases status {0}...'-f ($i + 1)

    # Wait a number of seconds between each polling of the status.
    Start-Sleep -S 5
    
    # Get the job's latest status.
    $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/jobs/{0}' -f $CompareDatabasesJob.Id) -Method Get -ContentType 'application/json'
    $CompareDatabasesJob = $Response.Content | ConvertFrom-Json

    if ($CompareDatabasesJob.Status -eq 'Finished') { break }
  }

  'Gathering results of the database comparison...'
  # Get the job's results once the status has finished.
  $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/databases/compare/results/{0}' -f $CompareDatabasesJob.Id) -Method Get -ContentType 'application/json'
  $CompareDatabasesResults = $Response.Content | ConvertFrom-Json

  'Database comparison complete'
} Catch {
  $_.Exception.Message
  exit 1
}