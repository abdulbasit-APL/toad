<#
.SYNOPSIS

Compare database tables.

.DESCRIPTION

Copyright (c) 2019 Quest Software Inc. ALL RIGHTS RESERVED.

A simple example that uses Toad DevOps Toolkit to compare database tables.

.NOTES

An example request body has been provided which should be customized to your setup.

By default the script fails (sets a non-zero exit code) when any exceptions occur.

.LINK

https://qsft.github.io/tdt-rest

#>

# By default the server uses a self-signed certificate.
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
# TLS 1.2 is required when communicating wih the server.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Try {
  $Body = @{
    Source = @{
      Connection = 'source_user/source_password@source_database'
      Schema = 'source_schema'
    }
    Target = @{
      Connection = 'target_user/target_password@target_database'
      Schema = 'target_schema'
    }
    Options = @{
      Sync = 'script'
    }
    Output = @{
      SyncScript = @{
        FilePath = 'C:\Examples\SyncScript.sql'
      }
    }
  }

  # Convert the PowerShell body to json.
  $Json = $Body | ConvertTo-Json

  'Requesting to compare tables...'
  $Response = Invoke-WebRequest -Uri 'https://localhost:5000/api/tables/compare' -Method Post -Body $Json -ContentType 'application/json'
  $CompareTablesJob = $Response.Content | ConvertFrom-Json

  # Poll the job until the compare tables job has an expected status of 'Finished' or the maximum number of retries has been hit.
  for ($i = 0; $i -lt 10; $i++) {
    'Polling the compare tables status {0}...'-f ($i + 1)

    # Wait a number of seconds between each polling of the status.
    Start-Sleep -S 5
    
    # Get the job's latest status.
    $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/jobs/{0}' -f $CompareTablesJob.Id) -Method Get -ContentType 'application/json'
    $CompareTablesJob = $Response.Content | ConvertFrom-Json

    if ($CompareTablesJob.Status -eq 'Finished') { break }
  }

  'Gathering results of the table comparison...'
  # Get the job's results once the status has finished.
  $Response = Invoke-WebRequest -Uri ('https://localhost:5000/api/tables/compare/results/{0}' -f $CompareTablesJob.Id) -Method Get -ContentType 'application/json'
  $CompareTablesResults = $Response.Content | ConvertFrom-Json

  'Database table comparison complete'
} Catch {
  $_.Exception.Message
  exit 1
}