﻿#---------------------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name          :  Jobs.py
#
# Description   :  Python Example of Toad DevOps Toolkit API (Code Analysis)
#
# Documentation :  https://qsft.github.io/tdt-rest/
#
# Assumptions   :  'requests' module installed.
#                  'urllib3'  module installed.
#
# Steps         :  1. List all jobs
#                  2. Delete Finished Jobs
#
# Sample Call   :  python {Directory}\Jobs.py
#---------------------------------------------------------------------------
import requests 
import json
import urllib3
import APIUtilities as utl


# Disable Python InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


# Variables
URL    = 'https://localhost:5000/api/jobs'               # Jobs URL
Header = {"Content-Type" : "application/json"}           # Request Header
 
       
def Get_ListJobs():
  try:
     print('--------------------------------------------------')
     print('Running: List Jobs...')
     
     # Run Get Jobs List
     utl.LogRequestInfo(URL, Header)
     response = requests.get(URL, headers=Header, verify=False)

     print('   Response Code     : ' + str(response.status_code))
     print('   Response JSON     : ' + response.text)
       
  except:
     print('Get_ListJobs - Unexpected Error')
     
     
                    
def Delete_Jobs(status):
  try:
     print('')
     print('--------------------------------------------------')
     print('Running: Delete (Finished) Jobs...')
     
     # Set Variables
     QueryURL = URL + '?status=' + status  

     # Run DELETE to remove Jobs
     utl.LogRequestInfo(QueryURL, Header)    
     response = requests.delete(QueryURL, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
    
  except:
     print('Delete_Jobs - Unexpected Error')
     
     
     
#---------------------------------------------------------------------------
# Main Process Calls
#---------------------------------------------------------------------------

# Print Header
print('--------------------------------------------------')
print('             Jobs Example                  ')
print('--------------------------------------------------')


# Step 1. List all jobs
Get_ListJobs()

# Step 2. Delete Finished Jobs
Delete_Jobs('Finished')


     
     
