﻿#---------------------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name          :  UnitTesting.py
#
# Description   :  Python Example of Toad DevOps Toolkit API (Unit Testing)
#
# Documentation :  https://qsft.github.io/tdt-rest/
#
# Assumptions   :  'requests' module installed.
#                  'urllib3'  module installed.
#
# Steps         :  1. List Unit Tests                    
#                  2. List Unit Test Suites              
#                  3. Run Unit Tests                     (Out: Job ID)
#                  4. Run Get Job Status                 (In:  Job ID, Max Attempts, Max Wait Time)
#                  5. Run Get Unit Test Results          (In:  Job ID)
#                  6. Run Unit Test Suites               (Out: Job ID)
#                  7. Run Get Job Status                 (In:  Job ID, Max Attempts, Max Wait Time)
#                  8. Run Get Unit Testing Results       (In:  Job ID)
#
# Sample Call   :  python {Directory}\UnitTesting.py
#---------------------------------------------------------------------------
import requests 
import json
import urllib3
import APIUtilities as utl


# Disable Python InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



# Variables
URL              = 'https://localhost:5000/api/unittests/codetester'        # Unit Testing URL
Header           = {"Content-Type" : 'application/json'}                    # Request Header 
SourceConnection = 'SOURCE_USER/source_pwd@sourcedb'                        # Source DB credentials
SourceSchema     = 'DEMO'                                                   # Source Schema
SourceObjName    = 'Test For DEMO_FUNCTION'                                 # Source Object Name
TargetConnection = 'TARGET_USER/target_pwd@targetdb'                        # Target DB credentials
TargetSchema     = 'DEMO'                                                   # Target Schema
SuiteUniversalID = '{F4309FDD-BF21-495A-80A6-01F1A5CE5134}'                 # Test Suite Universal ID 
OutputPath       = 'C:\Temp'                                                # Output Folder Path
  

def List_UnitTests():
  try:
     print('Running: List Unit Tests...')
     
     ListURL = URL + '/tests'

     # Set Payload with Variable Values
     Payload = {}
     Payload["connection"]    = "%s" %SourceConnection
     Payload["objects"]       = [{"owner"  : "%s" %SourceSchema},
                                 {"name"   : "%s" %SourceObjName}]
     Payload                  = json.dumps(Payload)
  
     # Run POST to Unit Testing
     utl.LogRequestInfo(ListURL, Header, Payload)    
     response = requests.post(ListURL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     retval = utl.ProcessResponse(response, 'id')

     print('')
     print('--------------------------------------------------')        
     
  except:
     print('List_UnitTests - Unexpected Error') 


def List_UnitTestSuites():
  try:
     print('Running: List Unit Test Suites...')
     
     ListSuitesURL = URL + '/testsuites'
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["connection"]    = "%s" %SourceConnection
     Payload["objects"]       = [{"owner"  : "%s" %SourceSchema}]
     Payload                  = json.dumps(Payload)
  
     # Run POST to Unit Testing
     utl.LogRequestInfo(ListSuitesURL, Header, Payload)    
     response = requests.post(ListSuitesURL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     retval = utl.ProcessResponse(response, 'id')

     print('')        
     print('--------------------------------------------------')     
     
  except:
     print('List_UnitTestSuites - Unexpected Error')      
     
     
def Run_UnitTest():
  try:
     print('Running: Unit Tests...')
     
     RunURL = URL + '/tests/run'
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["connection"]    = "%s" %SourceConnection
     Payload["objects"]       = [{"owner"  : "%s" %SourceSchema},
                                 {"name"   : "%s" %SourceObjName}]
     Payload["output"]        = {"folderPath"  : "%s" %OutputPath,
                                 "formats"     : ["txt", "xml"]}
     Payload                  = json.dumps(Payload)

       
     # Run POST to Unit Testing
     utl.LogRequestInfo(RunURL, Header, Payload)    
     response = requests.post(RunURL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id

     
  except:
     print('Run_UnitTest - Unexpected Error')     


def Run_UnitTestSuites():
  try:
     print('Running: Unit Test Suites...')
     
     RunSuitesURL = URL + '/testsuites/run'

     # Set Payload with Variable Values
     Payload = {}
     Payload["connection"]    = "%s" %SourceConnection
     Payload["universalIds"]  = ["%s" %SuiteUniversalID]
     Payload["output"]        = {"folderPath"  : "%s" %OutputPath,
                                 "formats"     : ["txt", "xml"]}
     Payload                  = json.dumps(Payload)

     # Run POST to Unit Testing
     utl.LogRequestInfo(RunSuitesURL, Header, Payload)    
     response = requests.post(RunSuitesURL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id
     
  except:
     print('Run_UnitTestSuites - Unexpected Error')

     
                     
def Get_UnitTestResults(id):
  try:
     print('')
     print('--------------------------------------------------')
     print('Running: Get Unit Test Results (id = ' + str(id) + ')...')
     
     # Set Variables
     ResultsURL = URL + '/tests/run/results/' + str(id)
     
     # Run Get Compare Database Results by ID
     utl.LogRequestInfo(ResultsURL, Header)
     response = requests.get(ResultsURL, headers=Header, verify=False)

     # Process Response 
     utl.ProcessResponse(response, None)
     
     
  except:
     print('Get_UnitTestingResults - Unexpected Error')

  finally:  
    print('--------------------------------------------------') 


def Get_UnitTestSuitesResults(id):
  try:
     print('')
     print('--------------------------------------------------')
     print('Running: Get Unit Test Suites Results (id = ' + str(id) + ')...')
     
     # Set Variables
     ResultsURL = URL + '/testsuites/run/results/' + str(id)
  
     # Run Get Results by ID 
     utl.LogRequestInfo(ResultsURL, Header)
     response = requests.get(ResultsURL, headers=Header, verify=False)

     # Process Response 
     utl.ProcessResponse(response, None)

  except:
     print('Get_UnitTestSuitesResults')
     
     

#---------------------------------------------------------------------------
# Main Process Calls
#---------------------------------------------------------------------------

# Print Header
print('--------------------------------------------------')
print('          Unit Testing Example                  ')
print('--------------------------------------------------')


# Step 1. List Unit Tests - returns Job ID
id = List_UnitTests()

# Step 2. List Unit Test Suites - returns Job ID
id = List_UnitTestSuites()

# Step 3. Run Unit Tests - returns Job ID
id = Run_UnitTest()

# Step 4. Run Get Job Status  (Connection) - returns job status; will retry until 'Finished' status or Max Retries (10); Wait 10 seconds between retries
jobstatus = utl.Get_JobStatus(id, 10, 10) 
   
# Step 5. Run Get Unit Testing Results - passes in Job ID
Get_UnitTestResults(id)  

# Step 6. Run Unit Test Suites - returns Job ID 
id = Run_UnitTestSuites()

# Step 7. Run Get Job Status (Snapshots) - returns job status; will retry until 'Finished' status or Max Retries (10); Wait 10 seconds between retries
jobstatus = utl.Get_JobStatus(id, 10, 10)

# Step 8. Run Get Unit Test Suites Results - passes in Job ID  
Get_UnitTestSuitesResults(id)  
