﻿#---------------------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name          :  ExecuteScripts.py
#
# Description   :  Python Example of Toad DevOps Toolkit API (Execute Scripts)
#
# Documentation :  https://qsft.github.io/tdt-rest/
#
# Assumptions   :  'requests' module installed.
#                  'urllib3'  module installed.
#
# Steps         :  1. Run Execute a Script   (Out: Job ID)
#                  2. Run Get Job Status     (In:  Job ID, Max Attempts, Max Wait Time)
#                  3. Run Get Script Results (In:  Job ID)
#
# Sample Call   :  python {Directory}\ExecuteScripts.py
#---------------------------------------------------------------------------
import requests 
import json
import urllib3
import APIUtilities as utl


# Disable Python InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



# Variables
URL          = 'https://localhost:5000/api/scripts/execute' # Execute Scripts URL
Connection   = 'source_user/source_pwd@sourcedb'            # Source DB credentials
Header       = {"Content-Type" : "application/json"}        # JSON Header
ScripttoRun  = 'C:\Temp\executescript.sql'                  # Input SQL File
ScriptOutput = 'C:\Temp\executescript_output.txt'           # Output text file
MaxRows      = 100                                          # Max Rows to display
jobstatus    = None 
     


# Run_Execute_Script - returns Job ID  
def Run_Execute_Script():
  try:
     print('Running: Execute script...')
     
     
     # Set Payload with Variable Values
     Payload = {}
     Payload["connection"] = "%s" %Connection
     Payload["script"]     = {"filepath": "%s" %ScripttoRun}
     Payload["output"]     = {"filepath": "%s" %ScriptOutput}  
     Payload["maxRows"]    = "%s" %MaxRows
     Payload               = json.dumps(Payload)
     
     # Run POST to Execute Script
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id
   
     
  except:
     print('Run_Execute_Script - Unexpected Error')
     
     
                 
# Run Get Script Results - passes in Job ID              
def Get_ScriptResults(id):
  try:
     print('')
     print('--------------------------------------------------')
     print('Running: Get Script Sesults (id = ' + str(id) + ')...')         
     
     # Set URL
     ResultsURL = URL + '/results/' + str(id)

     # Run Get by ID to get Script Execution Status
     utl.LogRequestInfo(ResultsURL, Header)
     response = requests.get(ResultsURL, headers=Header, verify=False)

     # Process Response 
     utl.ProcessResponse(response, None)
     
     
  except:
     print('Get_ScriptResults - Unexpected Error')    

  finally:  
    print('--------------------------------------------------') 



#---------------------------------------------------------------------------
# Main Process Calls
#---------------------------------------------------------------------------

# Print Header
print('--------------------------------------------------')
print('          Execute Script Example                  ')
print('--------------------------------------------------')


# Step 1.  Run Execute a Script - returns Job ID 
id = Run_Execute_Script()

# Step 2.  Run Get Job Status - returns job status; will retry until 'Finished' status or Max Retries (5); Wait 5 seconds between retries
jobstatus = utl.Get_JobStatus(id, 5, 5) 
   
# Step 3.  Run Get Script Results - passes in Job ID
Get_ScriptResults(id)       
     
     
