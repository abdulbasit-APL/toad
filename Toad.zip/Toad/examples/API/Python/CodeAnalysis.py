﻿#---------------------------------------------------------------------------
# Copyright (c) 2019 Quest Software
#
# Name          :  CodeAnalysis.py
#
# Description   :  Python Example of Toad DevOps Toolkit API (Code Analysis)
#
# Documentation :  https://qsft.github.io/tdt-rest/
#
# Assumptions   :  'requests' module installed.
#                  'urllib3'  module installed.
#
# Steps         :  1. Run Code Analysis Get Rulesets
#                  2. Run Code Analysis             (Out: Job ID)
#                  3. Run Get Job Status            (In:  Job ID, Max Attempts, Max Wait Time)
#                  4. Run Get Code Analysis Results (In:  Job ID)
#
# Sample Call   :  python {Directory}\CodeAnalysis.py
#---------------------------------------------------------------------------
import requests 
import json
import urllib3
import APIUtilities as utl


# Disable Python InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)



# Variables
URL               = 'https://localhost:5000/api/codeanalysis/run'          # Code Analysis Run URL
RuleSetsURL       = 'https://localhost:5000/api/codeanalysis/rulesets'     # Code Analysis RuleSets URL
Header            = {"Content-Type" : 'application/json'}                  # JSON Header
Connection        = 'source_user/source_pwd@sourcedb'                      # Source DB credentials
ObjectName        = 'DEMO_FUNCTION'                                        # Object Name
ObjectOwner       = 'DEMO'                                                 # Object Owner
ObjectType        = 'FUNCTION'                                             # Object Type
ScriptName        = 'C:\Temp\CodeAnalysis_ErrorScript.sql'                 # Script Name
RulesetName       = 'All Rules'                                            # Ruleset Name
OptionsReportName = 'QA - Code Analysis Report'                            # Report Name
OutputFolderPath  = 'C:\Temp'                                              # Output Folder Path
    


# Run_CodeAnalysis - returns Job ID  
def Run_CodeAnalysis():
  try:
     print('Running: Code Analysis...')
  
     # Set Payload with Variable Values
     Payload = {}
     Payload["connection"] = "%s" %Connection
     Payload["objects"]    = [{"name"       : "%s" %ObjectName,
                               "owner"      : "%s" %ObjectOwner,
                               "type"       : "%s" %ObjectType
                              }]
     Payload["scripts"]    = [{"filePath"   : "%s" %ScriptName}]                              
     Payload["options"]    = {"reportName"  : "%s" %OptionsReportName,
                              "ruleset"     : {"name" : "%s" %RulesetName}}                      
     Payload["output"]     = {"formats"     : ["html", "json", "xls", "xml"],
                              "folderPath"  : "%s" %OutputFolderPath}  
     Payload               = json.dumps(Payload)
     
     
     # Run POST to Code Analysis
     utl.LogRequestInfo(URL, Header, Payload)    
     response = requests.post(URL, data=Payload, headers=Header, verify=False)
     
     # Process Response 
     id = utl.ProcessResponse(response, 'id')
        
     return id
     
  except:
     print('Run_CodeAnalysis - Unexpected Error')
          
     
# Run Get Code Analysis Results - passes in Job ID              
def Get_CodeAnalysisResults(id):
  try:
     print('')
     print('--------------------------------------------------')
     print('Running: Get Script Sesults (id = ' + str(id) + ')...')
     
     # Set URL
     ResultsURL = URL + '/results/' + str(id)

     # Get CA Results
     utl.LogRequestInfo(ResultsURL, Header)
     response = requests.get(ResultsURL, headers=Header, verify=False)

     # Process Response 
     utl.ProcessResponse(response, None)
 
       
  except Exception as Error:
     print('Get_CodeAnalysisResults - Unexpected Error')
     
     
# Run Get Code Analysis Rulesets              
def Get_CodeAnalysisRulesets():
  try: 
     print('Running: Get Code Analysis Rulesets...')  
     
     # Set URL
     URL = RuleSetsURL

     # Run Get CA Rulesets
     utl.LogRequestInfo(URL, Header)
     response = requests.get(URL, headers=Header, verify=False)
 
     # Process Response 
     utl.ProcessResponse(response, None)
  
       
  except Exception as Error:
     print('Get_CodeAnalysisResults - Unexpected Error')   

  finally:  
    print('--------------------------------------------------') 



#---------------------------------------------------------------------------
# Main Process Calls
#---------------------------------------------------------------------------

# Print Header
print('--------------------------------------------------')
print('          Code Analysis Example                  ')
print('--------------------------------------------------')


# Step 1. Run Code Analysis Get Rulesets
id = Get_CodeAnalysisRulesets()

# Step 2. Run Code Analysis - returns Job ID
id = Run_CodeAnalysis()

# Step 3. Run Get Job Status - returns job status; will retry until 'Finished' status or Max Retries (5); Wait 5 seconds between retries
jobstatus = utl.Get_JobStatus(id, 5, 5) 
   
# Step 4. Run Get Code Analysis Results - passes in Job ID
Get_CodeAnalysisResults(id)        
     
     
