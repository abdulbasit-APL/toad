<RULESET title="Severe" version="11.0">
  <PROPERTIES>
    <SUMMARY>
      <RULESET_TYPE>Quest</RULESET_TYPE>
      <AUTHOR>Quest Software</AUTHOR>
      <CREATED>38447.6767106481</CREATED>
      <MODIFIED>38447.6768568171</MODIFIED>
      <COMMENTS>Rules in this set identify issues that are of a serious nature for the application now.</COMMENTS>
      <RULESET_TOTAL>7</RULESET_TOTAL>
    </SUMMARY>
  </PROPERTIES>
  <RULEFILTER>
    <SEVERITY sev="2" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>
