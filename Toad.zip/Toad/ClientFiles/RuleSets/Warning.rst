<RULESET title="Warning" version="11.0">
<PROPERTIES>
<SUMMARY>
<RULESET_TYPE>Quest</RULESET_TYPE>
<AUTHOR>Quest Software</AUTHOR>
<CREATED>38447.6780145486</CREATED>
<MODIFIED>38447.6781896875</MODIFIED>
<COMMENTS>Rules in this set identify issues that are not a problem currently, but could become a problem if not addressed.</COMMENTS>
<RULESET_TOTAL>26</RULESET_TOTAL>
</SUMMARY>
</PROPERTIES>
  <RULEFILTER>
    <SEVERITY sev="1" />
  </RULEFILTER>
  <RULES>
    <RULE rid="*" />
  </RULES>
</RULESET>
