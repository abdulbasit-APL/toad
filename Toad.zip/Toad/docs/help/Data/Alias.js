var xmlAliasData = "";
xmlAliasData += '<?xml version=\"1.0\" encoding=\"utf-8\"?>';
xmlAliasData += '<CatapultAliasFile>';
xmlAliasData += '    <Map Name=\"Welcome\" Link=\"Topics/Welcome.htm\" ResolvedId=\"1\" />';
xmlAliasData += '    <Map Name=\"GetStarted\" Link=\"Topics/GetStarted.htm\" ResolvedId=\"2\" />';
xmlAliasData += '</CatapultAliasFile>';
MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add('Alias', xmlAliasData);
